#include <stdio.h>
#include <math.h>
#include "mfcc.h"

int main() {
    printf("Testing MFCC implementation...\n");
    
    // Test basic audio parameters
    MFCCConfig config = {
        .sample_rate = 16000,
        .n_fft = 512,
        .n_mels = 80,
        .n_mfcc = 40,
        .fmin = 0.0f,
        .fmax = 8000.0f
    };
    
    // Create a simple test signal (sine wave)
    int signal_length = 16000; // 1 second of audio
    float test_signal[16000];
    for (int i = 0; i < signal_length; i++) {
        test_signal[i] = sin(2 * M_PI * 440 * i / 16000.0); // Using M_PI constant
    }
    
    // Compute MFCC
    float* mfcc_features = compute_mfcc(test_signal, signal_length, &config);
    
    // Print first few coefficients
    printf("First 5 MFCC coefficients:\n");
    for (int i = 0; i < 5; i++) {
        printf("MFCC[%d] = %f\n", i, mfcc_features[i]);
    }
    
    free(mfcc_features);  // Free allocated memory
    return 0;
}