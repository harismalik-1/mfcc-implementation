#ifndef TINY_ASR_MFCC_H
#define TINY_ASR_MFCC_H

#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

// Basic configuration structure
typedef struct {
    int sample_rate;    // Audio sample rate (e.g., 16000 Hz)
    int n_fft;         // FFT size
    int n_mels;        // Number of mel filterbanks
    int n_mfcc;        // Number of MFCC coefficients
    float fmin;        // Minimum frequency
    float fmax;        // Maximum frequency
} MFCCConfig;

// Function declarations
float* compute_mfcc(float* audio_signal, int signal_length, MFCCConfig* config);
float* create_mel_filterbank(MFCCConfig* config);

#ifdef __cplusplus
}
#endif

#endif // TINY_ASR_MFCC_H